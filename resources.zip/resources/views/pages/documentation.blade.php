@extends('layouts.front')

@section('content')

<section class="gradient-overly-right ptb-100 height-lg-100vh d-flex align-items-center" style="background: url('assets/img/hero-bg-4.jpg')no-repeat center center / cover">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-12">
                        <div class="hero-content-wrap text-white text-center pt-5 pt-sm-5 pt-lg-0 pt-md-0">
                            <h1 class="text-white">We Coming Soon!</h1>
                            <p class="lead">Searching for that perfect domain? Progressively benchmark turnkey innovation after quality channels. Dynamically synthesize multidisciplinary leadership.</p>

                        </div>
                    </div>
                </div>
            </div>
        </section>

@endsection