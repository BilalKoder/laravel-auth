@extends('layouts.front')

@section('content')

        <!--page header section start-->
        <section class="page-header-section ptb-100 gradient-overly-right" style="background: url('assets/img/hero-14.jpg')no-repeat center center / cover">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-7 col-lg-6">
                        <div class="page-header-content text-white">
                            <h1 class="text-white mb-2">Contact Us</h1>
                            <p class="lead">Enthusiastically provide access to multidisciplinary communities and reliable quality vectors. Globally administrate robust.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--page header section end-->



    
@endsection